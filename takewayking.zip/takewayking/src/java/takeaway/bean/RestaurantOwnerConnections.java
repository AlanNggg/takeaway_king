/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package takeaway.bean;

/**
 *
 * @author user
 */
public class RestaurantOwnerConnections {
    private String onwer_email, restaurant_id;

    public String getOnwer_email() {
        return onwer_email;
    }

    public void setOnwer_email(String onwer_email) {
        this.onwer_email = onwer_email;
    }

    public String getRestaurant_id() {
        return restaurant_id;
    }

    public void setRestaurant_id(String restaurant_id) {
        this.restaurant_id = restaurant_id;
    }
}
